<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "YOUR-DATABASE-USER");
define("DB_PASSWORD", "YOUR-DATABASE-PASSWORD");
define("DB_DATABASE", "gcm");

/*
 * Google Cloud Messaging API Key
 */
define("GOOGLE_API_KEY", "XXXXXXXXXXXXXXXXXXXXXX"); // Place your Google API Key
                          
?>