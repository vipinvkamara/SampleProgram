package com.coreservlets.eventsexercises1;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

/** Gives a sample solution to the first exercise from 
 *  the widget event handling section. Uses a named inner class.
 *  <p>
 *  From <a href="http://www.coreservlets.com/android-tutorial/">
 *  the coreservlets.com Android programming tutorial series</a>.
 */

public class EventsExercises1 extends Activity {
    /** Initializes the app when it is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); // Must call this before findViewById. 
        Button hiButton = (Button)findViewById(R.id.hi_button);
        Button byeButton = (Button)findViewById(R.id.bye_button);
        String hiMessage = getString(R.string.hi_message);
        String byeMessage = getString(R.string.bye_message);
        hiButton.setOnClickListener(new Toaster(hiMessage));
        byeButton.setOnClickListener(new Toaster(byeMessage));
    }
    
    /** Implements View.ClickListener. Uses the named inner class
     *  approach: see later exercise for version that uses separate class.
     */
    private class Toaster implements OnClickListener {
        private String mMessage;
        
        /** Builds a Listener that, when pressed, pops up a Toast that displays the given message. */
        
        public Toaster(String message) {
            mMessage = message;
        }
        
        /** Creates a Toast (temporary message) when button is clicked. */
        @Override
        public void onClick(View clickedButton) {
            Toast tempMessage =
                    Toast.makeText(EventsExercises1.this, 
                                   mMessage, 
                                   Toast.LENGTH_SHORT);
            tempMessage.show();
        }
    }
}